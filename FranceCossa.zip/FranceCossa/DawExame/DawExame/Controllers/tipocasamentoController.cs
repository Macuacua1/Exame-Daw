﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DawExame.Models;

namespace DawExame.Controllers
{
    public class tipocasamentoController : Controller
    {
        private ControleContext db = new ControleContext();

        // GET: /tipocasamento/
        public ActionResult Index()
        {
            return View(db.TipoCasamentoes.ToList());
        }

        // GET: /tipocasamento/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoCasamento tipocasamento = db.TipoCasamentoes.Find(id);
            if (tipocasamento == null)
            {
                return HttpNotFound();
            }
            return View(tipocasamento);
        }

        // GET: /tipocasamento/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /tipocasamento/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="TipoCasamentoId,Nome")] TipoCasamento tipocasamento)
        {
            if (ModelState.IsValid)
            {
                db.TipoCasamentoes.Add(tipocasamento);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tipocasamento);
        }

        // GET: /tipocasamento/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoCasamento tipocasamento = db.TipoCasamentoes.Find(id);
            if (tipocasamento == null)
            {
                return HttpNotFound();
            }
            return View(tipocasamento);
        }

        // POST: /tipocasamento/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="TipoCasamentoId,Nome")] TipoCasamento tipocasamento)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tipocasamento).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tipocasamento);
        }

        // GET: /tipocasamento/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoCasamento tipocasamento = db.TipoCasamentoes.Find(id);
            if (tipocasamento == null)
            {
                return HttpNotFound();
            }
            return View(tipocasamento);
        }

        // POST: /tipocasamento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TipoCasamento tipocasamento = db.TipoCasamentoes.Find(id);
            db.TipoCasamentoes.Remove(tipocasamento);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
