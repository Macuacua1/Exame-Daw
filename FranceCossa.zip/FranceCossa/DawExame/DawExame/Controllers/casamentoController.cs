﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DawExame.Models;

namespace DawExame.Controllers
{
    public class casamentoController : Controller
    {
        private ControleContext db = new ControleContext();

        // GET: /casamento/
        public ActionResult Index()
        {
            var casamentoes = db.Casamentoes.Include(c => c.TipoCasamento);
            return View(casamentoes.ToList());
        }

        // GET: /casamento/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Casamento casamento = db.Casamentoes.Find(id);
            if (casamento == null)
            {
                return HttpNotFound();
            }
            return View(casamento);
        }

        // GET: /casamento/Create
        public ActionResult Create()
        {
            ViewBag.TipoCasamentoId = new SelectList(db.TipoCasamentoes, "TipoCasamentoId", "Nome");
            return View();
        }

        // POST: /casamento/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="CasamentoId,TipoCasamentoId,CidadaoId,CidadaoaId,CidadaoxId,descricao,anoinicial,anoFinal,Estado")] Casamento casamento)
        {
            if (ModelState.IsValid)
            {
                db.Casamentoes.Add(casamento);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TipoCasamentoId = new SelectList(db.TipoCasamentoes, "TipoCasamentoId", "Nome", casamento.TipoCasamentoId);
            return View(casamento);
        }

        // GET: /casamento/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Casamento casamento = db.Casamentoes.Find(id);
            if (casamento == null)
            {
                return HttpNotFound();
            }
            ViewBag.TipoCasamentoId = new SelectList(db.TipoCasamentoes, "TipoCasamentoId", "Nome", casamento.TipoCasamentoId);
            return View(casamento);
        }

        // POST: /casamento/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="CasamentoId,TipoCasamentoId,CidadaoId,CidadaoaId,CidadaoxId,descricao,anoinicial,anoFinal,Estado")] Casamento casamento)
        {
            if (ModelState.IsValid)
            {
                db.Entry(casamento).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TipoCasamentoId = new SelectList(db.TipoCasamentoes, "TipoCasamentoId", "Nome", casamento.TipoCasamentoId);
            return View(casamento);
        }

        // GET: /casamento/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Casamento casamento = db.Casamentoes.Find(id);
            if (casamento == null)
            {
                return HttpNotFound();
            }
            return View(casamento);
        }

        // POST: /casamento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Casamento casamento = db.Casamentoes.Find(id);
            db.Casamentoes.Remove(casamento);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
