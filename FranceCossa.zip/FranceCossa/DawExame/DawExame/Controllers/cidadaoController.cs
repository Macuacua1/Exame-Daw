﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DawExame.Models;

namespace DawExame.Controllers
{
    public class cidadaoController : Controller
    {
        private ControleContext db = new ControleContext();

        // GET: /cidadao/
        public ActionResult Index()
        {
            var cidadaos = db.Cidadaos.Include(c => c.Provincia);
            return View(cidadaos.ToList());
        }

        // GET: /cidadao/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cidadao cidadao = db.Cidadaos.Find(id);
            if (cidadao == null)
            {
                return HttpNotFound();
            }
            return View(cidadao);
        }

        // GET: /cidadao/Create
        public ActionResult Create()
        {
            ViewBag.ProvinciaId = new SelectList(db.Provincias, "ProvinciaId", "Nome");
            return View();
        }

        // POST: /cidadao/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="CidadaoId,ProvinciaId,Nome,UserName,Nuit,Data")] Cidadao cidadao)
        {
            if (ModelState.IsValid)
            {
                db.Cidadaos.Add(cidadao);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ProvinciaId = new SelectList(db.Provincias, "ProvinciaId", "Nome", cidadao.ProvinciaId);
            return View(cidadao);
        }

        // GET: /cidadao/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cidadao cidadao = db.Cidadaos.Find(id);
            if (cidadao == null)
            {
                return HttpNotFound();
            }
            ViewBag.ProvinciaId = new SelectList(db.Provincias, "ProvinciaId", "Nome", cidadao.ProvinciaId);
            return View(cidadao);
        }

        // POST: /cidadao/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="CidadaoId,ProvinciaId,Nome,UserName,Nuit,Data")] Cidadao cidadao)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cidadao).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ProvinciaId = new SelectList(db.Provincias, "ProvinciaId", "Nome", cidadao.ProvinciaId);
            return View(cidadao);
        }

        // GET: /cidadao/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cidadao cidadao = db.Cidadaos.Find(id);
            if (cidadao == null)
            {
                return HttpNotFound();
            }
            return View(cidadao);
        }

        // POST: /cidadao/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Cidadao cidadao = db.Cidadaos.Find(id);
            db.Cidadaos.Remove(cidadao);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
