﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace DawExame.Models
{
    public class ControleContext : DbContext
    {
        public ControleContext()
            : base("DefaultConnection")
        {

        }
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        public System.Data.Entity.DbSet<DawExame.Models.Provincia> Provincias { get; set; }

        public System.Data.Entity.DbSet<DawExame.Models.TipoCasamento> TipoCasamentoes { get; set; }

        public System.Data.Entity.DbSet<DawExame.Models.Cidadao> Cidadaos { get; set; }

        public System.Data.Entity.DbSet<DawExame.Models.Casamento> Casamentoes { get; set; }

    
    }
}