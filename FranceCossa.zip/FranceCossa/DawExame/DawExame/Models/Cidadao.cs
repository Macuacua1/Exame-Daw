﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;


namespace DawExame.Models
{
    [Table("Cidadao")]
    public class Cidadao
    {
        public int CidadaoId { get; set; }

        public int ProvinciaId { get; set; }
        public virtual Provincia Provincia { get; set; }



        [Required]
        [Display(Name = "Nome Completo")]
        public string Nome { get; set; }

        [Required]
        [Display(Name = "BI")]
        public string UserName { get; set; }

        [Required]
        [Display(Name = "Nuit")]
        public string Nuit { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data de nascimento")]
        public DateTime Data { get; set; }


        public virtual ICollection<Casamento> Casamentos { get; set; }

     


    }
}