﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DawExame.Models
{
    [Table("Casamento")]
    public class Casamento
    {

        public int CasamentoId { get; set; }

        public int TipoCasamentoId { get; set; }
        public virtual TipoCasamento TipoCasamento { get; set; }

        public int CidadaoId { get; set; }
        public virtual Cidadao esposa { get; set; }

        public int CidadaoaId { get; set; }
        public virtual Cidadao esposo { get; set; }



        public int CidadaoxId { get; set; }
        public virtual Cidadao Cidadao { get; set; }


        [Required]
        [Display(Name = "Descricao")]
        public string descricao { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Ano inicial")]
        public DateTime anoinicial { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Ano Final")]
        public DateTime anoFinal { get; set; }

        [Display(Name = "Estado")]
        [Required(ErrorMessage = "O campo {0} deve ser preenchido!!!")]
        public bool Estado { get; set; }



        


       
    }
}