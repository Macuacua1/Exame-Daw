<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Provincia extends Model
{
    protected $primaryKey = "id";
    protected $fillable = [
        'nome'
    ];
    protected $table = "provincias";
/*
    public function cidadao()
    {
        return $this->hasMany('App\Cidadao', 'provincia_id', 'id');
    }
*/
}
