<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cidadao extends Model
{
    protected $primaryKey = "id";
    protected $fillable = [
        'nome',
        'bi',
        'nuit',
        'data_nascimento',
        'provincia_id'
    ];
    protected $table = "cidadaos";
/*
    public function provincia()
    {
        return $this->hasMany('App\Provincia', 'provincia_id', 'id');
    }
*/
}
