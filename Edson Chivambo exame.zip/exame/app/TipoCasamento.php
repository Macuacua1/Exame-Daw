<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoCasamento extends Model
{
    protected $primaryKey = "id";
    protected $fillable = [
        'nome',
    ];
    protected $table = "tipo_casamentos";
}
