<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Casamento extends Model
{
    protected $primaryKey = "id";
    protected $fillable = [
        'descricao',
        'tipoCasamento_id',
        'ano_inicio',
        'ano_fim',
        'esposo_id',
        'esposa_id',
        'estado'
    ];
    protected $table = "casamentos";
/*
    public function tipoCasamento()
    {
        return $this->hasMany('App\TipoCasamento', 'tipoCasamento_id', 'id');
    }

    public function esposo()
    {
        return $this->hasMany('App\Cidadao', 'esposo_id', 'id');
    }

    public function esposa()
    {
        return $this->hasMany('App\Cidadao', 'esposo_id', 'id');
    }
*/
}
