<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCasamentosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('casamentos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('descricao',250);
            $table->integer('tipoCasamento_id')->references('id')->on('tipocasamentos');
            $table->integer('ano_inicio');
            $table->integer('ano_fim')->nullable(true);
            $table->boolean('estado')->default(1);
            $table->integer('esposo_id')->references('id')->on('cidadaos');
            $table->integer('esposa_id')->references('id')->on('cidadaos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('casamentos');
    }
}
