<?php

use Illuminate\Database\Seeder;

class CidadaoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('cidadaos')->insert([
            'nome' => 'Ed Marcos',
            'bi' => '111252441C',
            'nuit' => '111252',
            'data_nascimento' => '1969-10-10',
            'provincia_id' => '1',
        ]);
        DB::table('cidadaos')->insert([
            'nome' => 'Julia Antonio',
            'bi' => '111252441A',
            'nuit' => '111552',
            'data_nascimento' => '1972-01-10',
            'provincia_id' => '1',
        ]);
        DB::table('cidadaos')->insert([
            'nome' => 'Marcos Filipe',
            'bi' => '1112441B',
            'nuit' => '131122',
            'data_nascimento' => '1962-03-10',
            'provincia_id' => '2',
        ]);
        DB::table('cidadaos')->insert([
            'nome' => 'MAria dos Anjos',
            'bi' => '1152441C',
            'nuit' => '554222',
            'data_nascimento' => '1990-05-09',
            'provincia_id' => '1',
        ]);
    }
}
