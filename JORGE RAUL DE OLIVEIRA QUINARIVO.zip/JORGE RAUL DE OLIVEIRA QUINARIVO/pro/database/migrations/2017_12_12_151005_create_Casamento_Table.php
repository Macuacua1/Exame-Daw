<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCasamentoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('casamentos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('descricao');
           
           
            $table->integer('TipoCasamento_id')->unsigned(); //Foreign Key
            $table->foreign('TipoCasamento_id')->references('id')->on('tipocasamentos');  
            $table->integer('ano_inicio')->nullable();

             $table->integer('ano_fim')->nullable();
             $table->string('estado')->nullable();

            $table->integer('esposo_id')->unsigned(); //Foreign Key
            $table->foreign('esposo_id')->references('id')->on('casados'); 

            $table->integer('esposa_id')->unsigned(); //Foreign Key
            $table->foreign('esposa_id')->references('id')->on('casados'); 

               
           // $table->integer('userlevel_id')->unsigned(); //Foreign Key
            //$table->foreign('userlevel_id')->references('id')->on('user_levels');


            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
     {
        Schema::dropIfExists('casamentos');
    }
}
