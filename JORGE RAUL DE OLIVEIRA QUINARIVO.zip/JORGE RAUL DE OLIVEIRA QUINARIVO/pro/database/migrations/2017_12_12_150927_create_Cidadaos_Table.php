<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCidadaosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
   {
        Schema::create('cidadaos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->integer('BI')->nullable();
            $table->integer('NUIT')->nullable();
            $table->integer('data_Nascimento')->nullable();
            $table->string('password');
            $table->rememberToken();   
             $table->integer('Provincia_id')->unsigned(); //Foreign Key
            $table->foreign('Provincia_id')->references('id')->on('provincias');  





            $table->integer('userlevel_id')->unsigned(); //Foreign Key
            $table->foreign('userlevel_id')->references('id')->on('user_levels');


            //$table->integer('contact')->nullable();
            
            //Endereco
           // $table->string('road')->default('None');
           // $table->string('av')->default('None');
            //$table->string('block')->default('None');
           // $table->string('province')->default('None');
           // $table->integer('number')->default('0');
           // $table->string('avatar')->default('default.jpg');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         
        Schema::dropIfExists('cidadaos');
    
    }
}
