<?php $__env->startSection('content'); ?>

<?php if(!empty($takeaways)): ?>
	<section id="media">

    <div class="page-header">
      <h1><?php echo e(count($takeaways)); ?> - TakeAways disponiveis na nossa provincia. </h1>
    </div>


    <?php $__currentLoopData = $takeaways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $takeaway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  		<ul class="media-list">			
              <li class="media">
                <a class="pull-left" href="#">
                  <img class="media-object" src="/uploads/avatars/<?php echo e($takeaway->logo); ?>">
                  
                </a>
                <div class="media-body">
                  <h4 class="media-heading"><?php echo e($takeaway->name); ?></h4>
                  <p><b>Aberto no periodo compriendido entre: </b><?php echo e($takeaway->opening_time); ?> as <?php echo e($takeaway->closing_time); ?>.</p>
                  <p>Nossos contactos: <b>Fixo</b>: <?php echo e($takeaway->mobile); ?>, <b>Movel:</b> <?php echo e($takeaway->phone); ?>, <b>E-mail:</b> <?php echo e($takeaway->email); ?>.</p>
                  <p><b>Com o endereco site:</b> <?php echo e($takeaway->road); ?>, <?php echo e($takeaway->number); ?>, <?php echo e($takeaway->province); ?>.</p>
                  <div id="mapa"></div>
                  <a href="<?php echo e(route('takeaway.details', $takeaway->id)); ?>">
                  <p>Mais detalhes</p></a>
                  <p><b>Website</b>: <i><?php echo e($takeaway->website); ?></i></p>
                  <!-- Nested media object -->
                  <?php $__currentLoopData = $takeaway->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="media">
                      <a class="pull-left" href="#">
                        <img class="media-object" src="/uploads/images/<?php echo e($product->image1); ?>">
                      </a>
                      <div class="media-body">
                        <h4 class="media-heading"><?php echo e($product->name); ?></h4>
                        <p><?php echo e($product->details); ?></p>
                        <p><strong>Preco: </strong><?php echo e($product->price); ?></p>
                        <p> 
                          <div>
                            <strong>Tag:</strong>
                              <label class="label label-info"><?php echo e($product->tags); ?></label>
                          </div>
                        </p>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  		</ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    <div class="pagination pagination-centered">
      <ul>
        <li class="active"><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">5</a></li>
      </ul>
    </div>
	</section>
  <?php endif; ?>

  <script>
    
            var map;
           
              function initMap() {
                  map = new google.maps.Map(document.getElementById('mapa'),{
                center:{lat: -25.913073,lng: 32.580812},
                zoom:13
            } );

             var marker = new google.maps.Marker({
                position: {lat: -25.913073, lng: 32.580812},
                map: map
            });
            
        }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtng5Ove_4jDibP7QGNHOXze482V8_Yjg&callback=initMap&libraries=places" async defer></script>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>