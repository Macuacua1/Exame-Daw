<?php $__env->startSection('content'); ?>

<section id="typography">
  <div class="bs-docs-example">
    <div class="hero-unit">
      <h1>Bem Vindo!</h1>
      <p>O TakeAway Locator &eacute; um website disponivel para publicitar produtos e servi&ccedil;os disponiveis em todos os TakeAways da provincia e cidade de Maputo.</p>
      <p><a class="btn btn-primary btn-large">Cadastre j&aacute; o seu TakeAway</a></p>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>