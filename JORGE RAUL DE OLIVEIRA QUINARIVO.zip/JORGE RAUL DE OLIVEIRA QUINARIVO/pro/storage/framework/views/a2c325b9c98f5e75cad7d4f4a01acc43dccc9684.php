<?php $__env->startSection('content'); ?>
<section id="forms">
                    <div class="page-header"> 
                       <h1> Login ao Takeaway Locator </h1> 
                    </div>

                    <div class="row">
                        <div class="span10 offset1">
                            <form class="bs-docs-example form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                              <?php echo e(csrf_field()); ?>                         
                              <div class="control-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label class="control-label" for="email" >O seu E-Mail</label>
                                <div div class="controls">
                                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="O seu E-Mail" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                              </div>
                              <div class="control-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label class="control-label" for="inputPassword">Password</label>
                                <div class="controls">
                                  <input id="password" type="password" name="password" placeholder="Password" required>
                                        <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                </div>
                              </div>
                              <div class="control-group">
                                <div class="controls">
                                  <label class="checkbox">
                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Gravar a Password.
                                  </label>
                                  <button type="submit" class="btn">Login</button>
                                  <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            Esqueceu a Password?
                                        </a>
                                </div>
                              </div>
                            </form>
                    </div>
                </div>


</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>