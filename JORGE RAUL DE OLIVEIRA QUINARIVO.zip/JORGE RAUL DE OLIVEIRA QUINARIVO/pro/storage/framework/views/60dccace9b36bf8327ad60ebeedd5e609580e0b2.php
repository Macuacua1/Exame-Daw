<?php $__env->startSection('content'); ?>
<section id="tables">
                <div class="conteiner">
                    <?php if(Session::has('success_msg')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
                    <?php endif; ?>
                <!-- Posts list -->
                <?php if(!empty($takeaways)): ?>
                    <div class="page-header">
                            <div >
                                <h1>Lista dos meus TakeAways</h1>
                            </div>
                            <div >
                                <a class="btn btn-success" href="<?php echo e(route('takeaway.add')); ?>"> Adicionar Novo Take Away</a>
                            </div>
                    </div>
                         <table class="table table-bordered table-striped table-hover">
                                <!-- Table Headings -->
                                <thead>
                                    <th width="10%">Codigo</th>
                                    <th width="55%">Nome</th>
                                    <th width="15%">Avenida</th>
                                  <th width="20%">Opera&ccedil;&atilde;o</th>
                                </thead>
                
                                <!-- Table Body -->
                                <tbody>
                                <?php $__currentLoopData = $takeaways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $takeaway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td >
                                            <div><?php echo e($takeaway->id); ?></div>
                                        </td>
                                        <td >
                                            <div><?php echo e($takeaway->name); ?></div>
                                        </td>
                                        <td >
                                            <div><?php echo e($takeaway->av); ?></div>
                                        </td>
                                        <td>
                                            
                                            <a href="<?php echo e(route('takeaway.details', $takeaway->id)); ?>">
                                              <i class="icon-eye-open"></i>
                                            </a>

                                            <a href="<?php echo e(route('takeaway.edit', $takeaway->id)); ?>">
                                              <i class="icon-pencil"></i>
                                            </a>

                                            <a href="<?php echo e(route('takeaway.delete', $takeaway->id)); ?>" onclick="return confirm('Tens a certeza que pretende remover?')">
                                                <i class="icon-trash"></i>
                                            </a>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                <?php endif; ?>
                </div>           
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>