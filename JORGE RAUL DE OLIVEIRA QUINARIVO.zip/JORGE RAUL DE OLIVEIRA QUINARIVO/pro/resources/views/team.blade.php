@extends('layouts.app')

@section('content') 

    <section id="media">
          <div class="page-header">
            <h1>Nossa Equipa</h1>
          </div>
          
          <div class="media">
            <a class="pull-left" href="#">
              <img class="media-object" src="http://placehold.it/64x64">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Aquilino Jone</h4>
				          DAW 2017, trabalho final da cadeira de DAW.
            </div>
          </div>
          <div class="media">
            <a class="pull-left" href="#">
              <img class="media-object" src="http://placehold.it/64x64">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Jorge Quinarivo</h4>
                   DAW 2017, trabalho final da cadeira de DAW.
            </div>
          </div>
          <div class="media">
            <a class="pull-left" href="#">
              <img class="media-object" src="http://placehold.it/64x64">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Stelio Tonica</h4>
                  DAW 2017, trabalho final da cadeira de DAW.
            </div>
          </div>
		</section>

@endsection