<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCasamentosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('casamentos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('descricao');
            $table->string('ano_inicio');
            $table->string('ano_fim');
            $table->string('estado');
            $table->string('data_nascimento');
            $table->integer('tipo_casamento_id')->unsigned();
            $table->foreign('tipo_casamento_id')->references('id')->on('tipo_casamentos')->onDelete('cascade');
            $table->integer('usuario_id')->unsigned();
            $table->foreign('usuario_id')->references('id')->on('users')->onDelete('cascade');
            $table->integer('esposa_id')->unsigned();
            $table->foreign('esposa_id')->references('id')->on('users')->onDelete('cascade');
            $table->integer('esposo_id')->unsigned();
            $table->foreign('esposo_id')->references('id')->on('users')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('casamentos');
    }
}
