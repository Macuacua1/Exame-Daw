<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cidadao extends Model
{
     protected $fillable = [
    	'nome', 'bi', 'nuit', 'data_nascimento', 'provincia_id','usuario_id'
    ];
}
