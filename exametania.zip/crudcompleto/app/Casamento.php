<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Casamento extends Model
{
    protected $fillable = [
    	'descricao', 'ano_inicio', 'ano_fim' 'estado', 'data_nascimento', 'tipo_casamento_id','usuario_id', 'esposa_id', 'esposo_id'
    ];
}