<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoCasamento extends Model
{
    'nome'
}
