@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Inbox:{{ count($casamentos) }}</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
				  <thead>
				    <tr>
				      <th>Nome</th>
				      <th>Descricao</th>
				    </tr>
				  </thead>
				  <tbody>

  	@foreach($casamentos as $casamento)
    <tr>
      <td>{{ \App\User::where('id', $casamento->usuario_id)->first()->name }}</td>
      <td><a href="/casamento/{{$casamento->id}}">{{ $casamentos->descricao }}</a></td>
      <td>{{ $casamento->estado }}</td>
    </tr>
    @endforeach
  </tbody>
</table>

{{ $casamentos->links()}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection