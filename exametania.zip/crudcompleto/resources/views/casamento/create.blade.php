@extends('layouts.app')

@section('content')
<div class="container">
<form name="formulario" method="post" action="/casamento">
   {{ csrf_field() }}

  <div class="form-group">
    <label>Autor</label>
    <input type="text" id="usuario_id" name="usuario_id" value="{{Auth::user()->name}}" disabled="">

    <input type="hidden" name="usuario_id" id="usuario_id" value="{{Auth::user()->id}}">
  </div>
  
  <div class="form-group">
    <label for="descricao">Descricao</label>
    <textarea class="form-control" name="descricao" id="descricao" required></textarea>
  </div>

<div>
	<label for="tipo_casamento_id">Tipo de casamento</label>
	<input type="number" name="tipo_casamento_id" id="tipo_casamento_id" value="{{Auth::user()->id}}">
</div>

 <div class="form-group">
    <label for="ano_inicio">Ano de casamento</label>
    <input class="form-control" name="ano_inicio" id="ano_inicio" required></input>
  </div>
   <div class="form-group">
    <label for="ano_fim">Ano de fim</label>
    <input class="form-control" name="ano_fim" id="ano_fim" required></input>
  </div>

   <div class="form-group">
    <label for="estado">Estado</label>
    <textarea class="form-control" name="estado" id="estado" required></textarea>
  </div>
<div>
	<label for="esposa_id">Esposa</label>
	<input type="number" name="esposa_id" id="esposa_id" value="{{Auth::user()->id}}">
</div>
<div>
	<label for="esposo_id">Esposo</label>
	<input type="number" name="esposo_id" id="esposo_id" value="{{Auth::user()->id}}">
</div>
   <input type="hidden" id="estado" name="estado" value="On">

  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Enviar</button>
    </div>
  </div>
</form>
</div>
@endsection